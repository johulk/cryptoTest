import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FiEye, FiEyeOff } from "react-icons/fi";
import { login } from '../services/AuthService.js';
import logoIcon from "../images/logo.png";

export default function LoginForm() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(null);
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            await login({ username, password });
            navigate('/');
        } catch (error) {
            setError(error.response?.data?.message || error.message || 'An error occurred');
        }
    };

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    return (
        <div id="login">
            <form onSubmit={handleSubmit}>
                <div className="image">
                    <img src={logoIcon} alt={'Glacial Link'} />
                </div>
                <h1>Welcome Back</h1>
                {error && (<div className="error">{error}</div>)}
                <ul>
                    <li>
                        <input
                            type="username"
                            id="username"
                            placeholder="Username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            required
                        />
                    </li>
                    <li>
                        <input
                            type={showPassword ? "text" : "password"}
                            id="password"
                            placeholder="Password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                        <button type="button" onClick={togglePasswordVisibility}>
                            {showPassword ? <FiEyeOff /> : <FiEye />}
                        </button>
                    </li>
                </ul>
                <Link to="/forgot-password" className="forgot-password">Forgot Password?</Link>
                <button type="submit" className="login">Log In</button>
                <Link to="/register">Don't have an account? Sign up</Link>
            </form>
        </div>
    );
}