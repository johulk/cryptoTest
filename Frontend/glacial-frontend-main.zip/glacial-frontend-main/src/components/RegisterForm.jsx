import { useState } from 'react';
import {Link, useNavigate} from 'react-router-dom';
import { register } from '../services/AuthService.js';
import { FiEye, FiEyeOff } from "react-icons/fi";
import logoIcon from "../images/logo.png";

export default function RegisterForm() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [walletSol, setWalletSol] = useState('');
    const [walletEth, setWalletEth] = useState('');
    const [error, setError] = useState(null);
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            await register({ username, password, walletSol, walletEth });
            navigate('/login');
        } catch (error) {
            setError(error.response?.data?.message || 'An error occurred');
        }
    };

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    return (
        <div id="register">
            <form onSubmit={handleSubmit}>
                <div className="image">
                    <img src={logoIcon} alt={'Glacial Link'}/>
                </div>
                <h1>Create Account</h1>
                {error && (<div className="error">{error}</div>)}
                <ul>
                    <li>
                        <input
                            type="text"
                            id="username"
                            placeholder="Username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            required
                        />
                    </li>
                    <li>
                        <input
                            type={showPassword ? "text" : "password"}
                            id="password"
                            placeholder="Password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                        <button type="button" onClick={togglePasswordVisibility}>
                            {showPassword ? <FiEyeOff/> : <FiEye/>}
                        </button>
                    </li>
                    <li>
                        <input
                            type="text"
                            id="walletEth"
                            placeholder="ETH wallet address (optional)"
                            value={walletEth}
                            onChange={(e) => setWalletEth(e.target.value)}
                        />
                    </li>
                    <li>
                        <input
                            type="text"
                            id="walletSol"
                            placeholder="SOL wallet address (optional)"
                            value={walletSol}
                            onChange={(e) => setWalletSol(e.target.value)}
                        />
                    </li>
                </ul>
                <button type="submit" className="register">Register</button>
                <Link to="/login">Already have an account? Sign in</Link>
            </form>
        </div>
    );
}