package dev.m1guel.glacial.dto;

import lombok.Getter;

@Getter
public class PasswordDto {

    private String currentPassword;
    private String newPassword;

}
