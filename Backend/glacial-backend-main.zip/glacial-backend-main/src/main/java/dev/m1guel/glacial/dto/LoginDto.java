package dev.m1guel.glacial.dto;

import lombok.Getter;

@Getter
public class LoginDto {

    private String username;
    private String password;

}