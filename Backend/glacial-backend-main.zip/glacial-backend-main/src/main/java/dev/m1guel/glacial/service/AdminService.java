package dev.m1guel.glacial.service;

public class AdminService {
}
